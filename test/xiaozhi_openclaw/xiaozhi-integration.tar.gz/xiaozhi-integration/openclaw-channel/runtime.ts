export type XiaozhiRuntime = {
  log: {
    info: (msg: string, ...args: unknown[]) => void;
    warn: (msg: string, ...args: unknown[]) => void;
    error: (msg: string, ...args: unknown[]) => void;
  };
  getChannelConfig: <T>(accountId: string) => T;
  processMessage: (message: unknown) => Promise<void>;
  registerOutboundHandler: (
    handler: (data: { accountId: string; deviceId: string; content: string; sessionId?: string }) => Promise<void>,
  ) => () => void;
};

let xiaozhiRuntime: XiaozhiRuntime | null = null;

export function setXiaozhiRuntime(runtime: XiaozhiRuntime): void {
  xiaozhiRuntime = runtime;
}

export function getXiaozhiRuntime(): XiaozhiRuntime {
  if (!xiaozhiRuntime) {
    throw new Error("Xiaozhi runtime not initialized");
  }
  return xiaozhiRuntime;
}
