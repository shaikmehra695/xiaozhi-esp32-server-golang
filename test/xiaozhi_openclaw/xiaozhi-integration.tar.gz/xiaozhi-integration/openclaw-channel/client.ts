import WebSocket from "ws";
import type { XiaozhiAccount, XiaozhiConnection, XiaozhiInboundMessage, WebSocketMessage } from "./types.js";
import { sendPing, sendPong, sendError, sendClose } from "./send.js";
import { generateUUID } from "openclaw/shared";

export type XiaozhiClientOptions = {
  account: XiaozhiAccount;
  onMessage: (message: XiaozhiInboundMessage) => void;
  onConnect: () => void;
  onDisconnect: (error?: Error) => void;
  log?: {
    info: (msg: string, ...args: unknown[]) => void;
    warn: (msg: string, ...args: unknown[]) => void;
    error: (msg: string, ...args: unknown[]) => void;
  };
};

export class XiaozhiClient {
  private account: XiaozhiAccount;
  private ws: WebSocket | null = null;
  private connection: XiaozhiConnection | null = null;
  private heartbeatInterval: NodeJS.Timeout | null = null;
  private heartbeatTimeout: NodeJS.Timeout | null = null;
  private pingSeq = 0;
  private missedPings = 0;
  private reconnectTimeout: NodeJS.Timeout | null = null;
  private isShuttingDown = false;
  private handshakeComplete = false;

  private onMessage: (message: XiaozhiInboundMessage) => void;
  private onConnect: () => void;
  private onDisconnect: (error?: Error) => void;
  private log: XiaozhiClientOptions["log"];

  constructor(options: XiaozhiClientOptions) {
    this.account = options.account;
    this.onMessage = options.onMessage;
    this.onConnect = options.onConnect;
    this.onDisconnect = options.onDisconnect;
    this.log = options.log || console;
  }

  start(): void {
    this.isShuttingDown = false;
    this.connect();
  }

  stop(): void {
    this.isShuttingDown = true;
    this.clearHeartbeat();
    this.clearReconnect();
    if (this.connection) {
      sendClose(this.connection, "Client shutdown", 1000);
    }
    if (this.ws) {
      this.ws.close();
    }
  }

  private connect(): void {
    if (this.isShuttingDown) {
      return;
    }

    this.log?.info(`[xiaozhi:${this.account.accountId}] connecting to ${this.account.url}`);

    try {
      this.ws = new WebSocket(`${this.account.url}?token=${this.account.token}`);

      this.setupWebSocketHandlers();
    } catch (error) {
      this.log?.error(`[xiaozhi:${this.account.accountId}] connection failed`, error);
      this.scheduleReconnect();
    }
  }

  private setupWebSocketHandlers(): void {
    if (!this.ws) {
      return;
    }

    this.ws.onopen = () => {
      this.log?.info(`[xiaozhi:${this.account.accountId}] connected`);
      this.handshakeComplete = false;
    };

    this.ws.onmessage = (event) => {
      this.handleMessage(event.data.toString());
    };

    this.ws.onerror = (error) => {
      this.log?.error(`[xiaozhi:${this.account.accountId}] websocket error`, error);
    };

    this.ws.onclose = (event) => {
      this.log?.info(`[xiaozhi:${this.account.accountId}] disconnected`, {
        code: event.code,
        reason: event.reason,
      });
      this.clearHeartbeat();
      this.onDisconnect(new Error(`WebSocket closed: ${event.code} ${event.reason}`));

      if (!this.isShuttingDown) {
        this.scheduleReconnect();
      }
    };
  }

  private handleMessage(data: string): void {
    try {
      const message: WebSocketMessage = JSON.parse(data);

      switch (message.type) {
        case "handshake_ack":
          this.handleHandshakeAck(message);
          break;
        case "message":
          this.handleUserMessage(message);
          break;
        case "ping":
          this.handlePing(message);
          break;
        case "pong":
          this.handlePong(message);
          break;
        case "error":
          this.handleError(message);
          break;
        case "close":
          this.handleClose(message);
          break;
        default:
          this.log?.warn(`[xiaozhi:${this.account.accountId}] unknown message type: ${message.type}`);
      }
    } catch (error) {
      this.log?.error(`[xiaozhi:${this.account.accountId}] failed to parse message`, error);
    }
  }

  private handleHandshakeAck(message: WebSocketMessage & { type: "handshake_ack" }): void {
    if (this.handshakeComplete) {
      return;
    }

    this.log?.info(
      `[xiaozhi:${this.account.accountId}] received handshake_ack from ${message.payload.server}`,
    );

    // Send handshake
    const handshake = {
      id: generateUUID(),
      timestamp: Date.now(),
      type: "handshake",
      payload: {
        version: "1.0.0",
        client: "openclaw-gateway",
        capabilities: ["text"],
      },
    };

    this.ws?.send(JSON.stringify(handshake));

    this.handshakeComplete = true;
    this.startHeartbeat();
    this.onConnect();
  }

  private handleUserMessage(message: WebSocketMessage & { type: "message" }): void {
    if (!this.connection) {
      this.log?.warn(`[xiaozhi:${this.account.accountId}] received message before connection established`);
      return;
    }

    const inbound: XiaozhiInboundMessage = {
      channel: "xiaozhi",
      accountId: this.account.accountId,
      userId: this.connection.claims.user_id,
      deviceId: this.connection.claims.device_id,
      agentId: this.connection.claims.agent_id,
      content: message.payload.content,
      sessionId: message.payload.session_id,
      timestamp: message.timestamp,
    };

    this.onMessage(inbound);
  }

  private handlePing(message: WebSocketMessage & { type: "ping" }): void {
    if (this.connection) {
      sendPong(this.connection, message.id, message.payload.seq);
    }
  }

  private handlePong(message: WebSocketMessage & { type: "pong" }): void {
    if (this.connection) {
      this.connection.lastPongAt = Date.now();
      this.missedPings = 0;
    }
  }

  private handleError(message: WebSocketMessage & { type: "error" }): void {
    this.log?.warn(
      `[xiaozhi:${this.account.accountId}] received error: ${message.payload.code} - ${message.payload.message}`,
    );
  }

  private handleClose(message: WebSocketMessage & { type: "close" }): void {
    this.log?.info(`[xiaozhi:${this.account.accountId}] received close: ${message.payload.code}`);
    this.ws?.close(message.payload.code, message.payload.reason);
  }

  private startHeartbeat(): void {
    this.clearHeartbeat();

    this.heartbeatInterval = setInterval(() => {
      this.sendHeartbeat();
    }, this.account.heartbeatInterval);
  }

  private sendHeartbeat(): void {
    if (!this.connection || !this.ws || this.ws.readyState !== WebSocket.OPEN) {
      return;
    }

    this.pingSeq++;

    // Set timeout for pong
    this.heartbeatTimeout = setTimeout(() => {
      this.missedPings++;
      this.log?.warn(`[xiaozhi:${this.account.accountId}] heartbeat timeout, missed: ${this.missedPings}`);

      if (this.missedPings >= 3) {
        this.log?.error(`[xiaozhi:${this.account.accountId}] too many missed heartbeats, reconnecting`);
        if (this.ws) {
          this.ws.close(1000, "Heartbeat timeout");
        }
      }
    }, this.account.heartbeatTimeout);

    sendPing(this.connection, this.pingSeq);
  }

  private clearHeartbeat(): void {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
    if (this.heartbeatTimeout) {
      clearTimeout(this.heartbeatTimeout);
      this.heartbeatTimeout = null;
    }
  }

  private scheduleReconnect(): void {
    this.clearReconnect();

    this.reconnectTimeout = setTimeout(() => {
      this.log?.info(`[xiaozhi:${this.account.accountId}] reconnecting...`);
      this.connect();
    }, this.account.reconnectInterval);
  }

  private clearReconnect(): void {
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
      this.reconnectTimeout = null;
    }
  }

  getConnection(): XiaozhiConnection | null {
    return this.connection;
  }

  setConnection(connection: XiaozhiConnection): void {
    this.connection = connection;
  }

  getWebSocket(): WebSocket | null {
    return this.ws;
  }

  setWebSocket(ws: WebSocket): void {
    this.ws = ws;
  }
}
