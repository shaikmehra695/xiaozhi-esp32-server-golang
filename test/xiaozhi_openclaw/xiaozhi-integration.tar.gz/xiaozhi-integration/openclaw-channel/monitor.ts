import WebSocket from "ws";
import type { XiaozhiAccount, XiaozhiConnection, XiaozhiInboundMessage } from "./types.js";
import type { XiaozhiRuntime } from "./runtime.js";
import { XiaozhiClient } from "./client.js";
import { sendMessageXiaozhi } from "./send.js";
import { generateSessionId } from "./utils.js";

export type MonitorStatusSink = (patch: {
  running?: boolean;
  lastStartAt?: number | null;
  lastStopAt?: number | null;
  lastError?: string | null;
}) => void;

export type MonitorOptions = {
  accountId: string;
  config: unknown;
  runtime: XiaozhiRuntime;
  abortSignal: AbortSignal;
  statusSink: MonitorStatusSink;
};

export async function monitorXiaozhiProvider(options: MonitorOptions): Promise<{ stop: () => void }> {
  const { accountId, config, runtime, abortSignal, statusSink } = options;

  const log = {
    info: (msg: string, ...args: unknown[]) => runtime.log.info(`[xiaozhi:${accountId}] ${msg}`, ...args),
    warn: (msg: string, ...args: unknown[]) => runtime.log.warn(`[xiaozhi:${accountId}] ${msg}`, ...args),
    error: (msg: string, ...args: unknown[]) => runtime.log.error(`[xiaozhi:${accountId}] ${msg}`, ...args),
  };

  // Extract token claims
  const account = runtime.getChannelConfig<XiaozhiAccount>(accountId);
  const claims = parseTokenClaims(account.token);

  const sessionIds = new Map<string, string>();

  const client = new XiaozhiClient({
    account,
    onMessage: (message) => handleMessage(message),
    onConnect: () => {
      log.info("connected");
      statusSink({
        running: true,
        lastStartAt: Date.now(),
        lastError: null,
      });
    },
    onDisconnect: (error) => {
      log.warn("disconnected", error?.message);
      statusSink({
        running: false,
        lastStopAt: Date.now(),
        lastError: error?.message ?? "Unknown error",
      });
    },
    log,
  });

  // Create connection when WebSocket connects
  const connection: XiaozhiConnection = {
    accountId,
    ws: {} as WebSocket,
    claims,
    connectedAt: 0,
    lastPingAt: 0,
    lastPongAt: 0,
    sessionIds,
  };

  client.setConnection(connection);

  async function handleMessage(message: XiaozhiInboundMessage): Promise<void> {
    try {
      // Generate or retrieve session ID
      let sessionId = sessionIds.get(message.deviceId);
      if (!sessionId) {
        sessionId = generateSessionId(message.userId, message.deviceId);
        sessionIds.set(message.deviceId, sessionId);
      }

      // Forward to gateway
      await runtime.processMessage({
        channel: "xiaozhi",
        accountId: message.accountId,
        target: message.deviceId,
        text: message.content,
        sessionId,
        userId: message.userId,
        agentId: message.agentId,
        timestamp: message.timestamp,
      });
    } catch (error) {
      log.error("failed to process message", error);
    }
  }

  async function sendResponse(deviceId: string, content: string, sessionId?: string): Promise<void> {
    if (!connection.ws || connection.ws.readyState !== WebSocket.OPEN) {
      log.warn("cannot send response: not connected");
      return;
    }

    const correlationId = undefined; // Can track message IDs if needed
    const result = await sendMessageXiaozhi(connection, { deviceId, content, sessionId }, correlationId);

    if (!result.success) {
      log.error("failed to send response", result.error);
    }
  }

  // Register outbound handler
  const unsubscribe = runtime.registerOutboundHandler(
    async (data: { accountId: string; deviceId: string; content: string; sessionId?: string }) => {
      if (data.accountId === accountId) {
        await sendResponse(data.deviceId, data.content, data.sessionId);
      }
    },
  );

  // Handle abort signal
  abortSignal.addEventListener("abort", () => {
    client.stop();
    unsubscribe();
  });

  // Start client
  client.start();

  return {
    stop: () => {
      client.stop();
      unsubscribe();
    },
  };
}

function parseTokenClaims(token: string): XiaozhiConnection["claims"] {
  try {
    // Token should be JWT, extract payload
    const parts = token.split(".");
    if (parts.length !== 3) {
      throw new Error("Invalid token format");
    }

    const payload = JSON.parse(Buffer.from(parts[1], "base64").toString("utf-8"));

    return {
      user_id: payload.user_id || "",
      agent_id: payload.agent_id || "",
      device_id: payload.device_id || "",
      exp: payload.exp || 0,
      iat: payload.iat || 0,
    };
  } catch (error) {
    throw new Error(`Failed to parse token claims: ${error}`);
  }
}
