import type { XiaozhiConnection, XiaozhiOutboundMessage } from "./types.js";
import { generateUUID } from "openclaw/shared";

export async function sendMessageXiaozhi(
  connection: XiaozhiConnection,
  message: XiaozhiOutboundMessage,
  correlationId?: string,
): Promise<{ id: string; success: boolean; error?: string }> {
  const id = generateUUID();
  const timestamp = Date.now();

  try {
    const payload: Record<string, unknown> = {
      content: message.content,
    };

    if (message.sessionId) {
      payload.session_id = message.sessionId;
    }

    const wsMessage = {
      id,
      timestamp,
      type: "response",
      ...(correlationId ? { correlation_id: correlationId } : {}),
      payload,
    };

    connection.ws.send(JSON.stringify(wsMessage));

    return { id, success: true };
  } catch (error) {
    return {
      id,
      success: false,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

export async function sendPing(
  connection: XiaozhiConnection,
  seq: number,
): Promise<{ success: boolean; error?: string }> {
  try {
    const wsMessage = {
      id: generateUUID(),
      timestamp: Date.now(),
      type: "ping",
      payload: { seq },
    };

    connection.ws.send(JSON.stringify(wsMessage));
    connection.lastPingAt = Date.now();

    return { success: true };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

export async function sendPong(
  connection: XiaozhiConnection,
  correlationId: string,
  seq: number,
): Promise<{ success: boolean; error?: string }> {
  try {
    const wsMessage = {
      id: generateUUID(),
      timestamp: Date.now(),
      type: "pong",
      correlation_id: correlationId,
      payload: { seq },
    };

    connection.ws.send(JSON.stringify(wsMessage));

    return { success: true };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

export async function sendError(
  connection: XiaozhiConnection,
  code: string,
  message: string,
  correlationId?: string,
): Promise<{ success: boolean; error?: string }> {
  try {
    const wsMessage = {
      id: generateUUID(),
      timestamp: Date.now(),
      type: "error",
      ...(correlationId ? { correlation_id: correlationId } : {}),
      payload: { code, message },
    };

    connection.ws.send(JSON.stringify(wsMessage));

    return { success: true };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

export async function sendClose(
  connection: XiaozhiConnection,
  reason: string,
  code: number = 1000,
): Promise<{ success: boolean; error?: string }> {
  try {
    const wsMessage = {
      id: generateUUID(),
      timestamp: Date.now(),
      type: "close",
      payload: { reason, code },
    };

    connection.ws.send(JSON.stringify(wsMessage));
    connection.ws.close(code, reason);

    return { success: true };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}
