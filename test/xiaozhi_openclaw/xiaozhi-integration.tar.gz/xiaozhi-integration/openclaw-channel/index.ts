import type { ChannelPlugin, OpenClawPluginApi } from "openclaw/plugin-sdk";
import { emptyPluginConfigSchema } from "openclaw/plugin-sdk";
import { xiaozhiPlugin } from "./channel.js";
import { setXiaozhiRuntime } from "./runtime.js";

const plugin = {
  id: "xiaozhi",
  name: "XiaoZhi ESP32",
  description: "XiaoZhi ESP32 Server WebSocket channel integration",
  configSchema: emptyPluginConfigSchema(),
  version: "1.0.0",
  register(api: OpenClawPluginApi) {
    // Set up runtime
    setXiaozhiRuntime({
      log: api.runtime.log,
      getChannelConfig: <T>(accountId: string): T => {
        return api.runtime.getChannelConfig?.(accountId) as T;
      },
      processMessage: async (message) => {
        // This would be implemented by the Gateway to process inbound messages
        // For now, we'll need to hook into the Gateway's message processing
        await (api as any).processMessage?.(message);
      },
      registerOutboundHandler: (handler) => {
        // Register outbound handler for sending responses back to xiaozhi
        return (api as any).registerOutboundHandler?.(handler) || (() => {});
      },
      getConnection: (accountId: string) => {
        // Get active connection for an account
        return (api as any).getConnection?.(accountId);
      },
    });

    // Register channel plugin
    api.registerChannel({ plugin: xiaozhiPlugin as ChannelPlugin });
  },
};

export default plugin;
