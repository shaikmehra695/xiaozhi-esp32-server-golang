#!/usr/bin/env node

const jwt = require('jsonwebtoken');

// 读取命令行参数
const userId = process.argv[2] || 'user-123';
const agentId = process.argv[3] || 'main';
const deviceId = process.argv[4] || 'esp32-001';
const expiresIn = process.argv[5] || '24h';
const secret = process.env.JWT_SECRET || 'your-secret-key-change-me';

// 生成 token
const payload = {
  user_id: userId,
  agent_id: agentId,
  device_id: deviceId,
};

const token = jwt.sign(payload, secret, { expiresIn });

console.log('=== XiaoZhi JWT Token ===');
console.log();
console.log('Token:', token);
console.log();
console.log('Payload:', JSON.stringify(payload, null, 2));
console.log();
console.log('Expires in:', expiresIn);
console.log('Secret:', secret);
